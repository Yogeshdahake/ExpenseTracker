package com.arc.yogesh.expensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button cr = (Button)this.findViewById(R.id.btn_main_cr);
        Button db = (Button)this.findViewById(R.id.btn_main_db);
        Button sh = (Button)this.findViewById(R.id.btn_main_rep);
        Button bal = (Button)this.findViewById(R.id.btn_main_balance);

        Button cal = (Button)this.findViewById(R.id.calid);




        cr.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Credit.class);
                startActivity(in);
                finish();
            }
        });
        sh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Report.class);
                startActivity(in);
                finish();
            }
        });
        db.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Debit.class);
                startActivity(in);
                finish();
            }
        });
        bal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Bal_Report.class);
                startActivity(in);
                finish();
            }
        });

        cal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Calculator.class);
                startActivity(in);
                finish();
            }
        });



    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        this.finish();
    }



}
